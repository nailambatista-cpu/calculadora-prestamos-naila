function usd(n) {
  return '$ ' + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function showError(msg) {
  document.getElementById('errorText').textContent = msg;
  document.getElementById('errorBox').classList.add('show');
  document.getElementById('resultsSection').classList.remove('show');
}

function limpiar() {
  ['monto', 'tasa', 'meses'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('errorBox').classList.remove('show');
  document.getElementById('resultsSection').classList.remove('show');
  document.getElementById('monto').focus();
}

function calcular() {
  const mStr = document.getElementById('monto').value.trim();
  const tStr = document.getElementById('tasa').value.trim();
  const nStr = document.getElementById('meses').value.trim();

  // Validar campos vacíos
  if (!mStr || !tStr || !nStr) {
    showError('Por favor, complete todos los campos antes de calcular.');
    return;
  }

  const P  = parseFloat(mStr.replace(/,/g, ''));
  const ta = parseFloat(tStr.replace(',', '.'));
  const n  = parseInt(nStr);

  // Validar que sean números válidos
  if (isNaN(P))  { showError('El monto del préstamo debe ser un número válido. Ej: 50000'); return; }
  if (isNaN(ta)) { showError('La tasa de interés debe ser un número válido. Ej: 12 o 5.5'); return; }
  if (isNaN(n))  { showError('La cantidad de meses debe ser un número entero. Ej: 60'); return; }

  // Validar que sean mayores a cero
  if (P  <= 0) { showError('El monto del préstamo debe ser mayor a cero.'); return; }
  if (ta <= 0) { showError('La tasa de interés debe ser mayor a cero.'); return; }
  if (n  <= 0) { showError('La cantidad de meses debe ser mayor a cero.'); return; }

  // Fórmula de amortización: M = P × [r(1+r)^n] / [(1+r)^n - 1]
  const r = ta / 12 / 100;
  let cuota;

  if (r === 0) {
    cuota = P / n;
  } else {
    const pot = Math.pow(1 + r, n);
    cuota = P * (r * pot) / (pot - 1);
  }

  // Construir tabla de amortización
  const tbody = document.getElementById('tableBody');
  tbody.innerHTML = '';

  let saldo = P;
  let sumCuota = 0, sumCapital = 0, sumInteres = 0;

  for (let i = 1; i <= n; i++) {
    const intMes = saldo * r;
    const capMes = cuota - intMes;
    saldo = Math.max(0, saldo - capMes);

    sumCuota   += cuota;
    sumCapital += capMes;
    sumInteres += intMes;

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${i}</td>
      <td>${usd(cuota)}</td>
      <td class="capital">${usd(capMes)}</td>
      <td class="interes">${usd(intMes)}</td>
      <td class="saldo">${usd(saldo)}</td>
    `;
    tbody.appendChild(tr);
  }

  // Totales en el footer de la tabla
  document.getElementById('ftCuota').textContent   = usd(sumCuota);
  document.getElementById('ftCapital').textContent = usd(sumCapital);
  document.getElementById('ftInteres').textContent = usd(sumInteres);

  // Tarjetas de resumen
  document.getElementById('rCuota').textContent    = usd(cuota);
  document.getElementById('rMeses').textContent    = n;
  document.getElementById('rInteres').textContent  = usd(sumInteres);
  document.getElementById('rTotal').textContent    = usd(sumCuota);
  document.getElementById('tableBadge').textContent = n + ' cuotas';

  // Mostrar resultados
  document.getElementById('errorBox').classList.remove('show');
  const sec = document.getElementById('resultsSection');
  sec.classList.add('show');
  setTimeout(() => sec.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
}

// Solo permitir entrada numérica en los campos
['monto', 'tasa', 'meses'].forEach(id => {
  document.getElementById(id).addEventListener('keypress', e => {
    if (!/[0-9.,]/.test(e.key)) e.preventDefault();
  });
  document.getElementById(id).addEventListener('keydown', e => {
    if (e.key === 'Enter') calcular();
  });
});
